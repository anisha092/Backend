import React from 'react'
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom'
import User from './Components/User'
import CreateProducts from './Components/CreateProducts'
import UpdateProduct from './Components/UpdateProduct'
const App = () => {
  return (
    <div>
      <Router>
        <Routes>
          <Route path="/" element={<User />} />
          <Route path="/create" element={<CreateProducts />} />
          <Route path="/update" element={<UpdateProduct />} />
        </Routes>
      </Router>
    </div>
  )
}

export default App
