import React, { useState } from "react";
import axios from 'axios';
const CreateProducts = () => {
  const [data, setData] = useState({
    name: "",
    quantity: "",
    price: "",
  });
  const submit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:3000/api/products", data)
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="d-flex vh-100 bg-primary justify-content-center align-item-center">
      <div className="w-50 bg-white rounded p-3">
        <form onSubmit={submit}>
          <h2>Add User</h2>
          <div className="mb-2">
            <label htmlFor="">Name</label>
            <input
              type="text"
              placeholder="Enter Name"
              className="form-control"
              onChange={(e) => {
                setData({ ...data, name: e.target.value });
              }}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="">Quantity</label>
            <input
              type="text"
              placeholder="Enter Quantity"
              className="form-control"
              onChange={(e) => {
                setData({ ...data, quantity: e.target.value });
              }}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="">price</label>
            <input
              type="text"
              placeholder="Enter Age"
              className="form-control"
              onChange={(e) => {
                setData({ ...data, price: e.target.value });
              }}
            />
          </div>
          <button className="btn btn-success">Submit </button>
        </form>
      </div>
    </div>
  );
};

export default CreateProducts;
