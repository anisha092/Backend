import React, { useState } from 'react';
import axios from 'axios';

const UpdateProduct = () => {
  const [update, setUpdate] = useState({
    id: '',
    name: '',
    quantity: '',
    price: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdate({ ...update, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:3000/api/products/${update.id}`, {
      name: update.name,
      quantity: update.quantity,
      price: update.price
    })
      .then(response => {
        console.log('Product updated successfully:', response.data);
      })
      .catch(error => {
        console.error('Error updating product:', error);
      });
  };
  
  return (
    <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
      <div className="w-50 bg-white rounded p-3">
        <form onSubmit={handleSubmit}>
          <h2>Update Product</h2>
          <div className="mb-2">
            <label htmlFor="id">ID</label>
            <input
              type="text"
              name="id"
              placeholder="Enter ID"
              className="form-control"
              value={update.id}
              onChange={handleInputChange}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              name="name"
              placeholder="Enter Name"
              className="form-control"
              value={update.name}
              onChange={handleInputChange}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="quantity">Quantity</label>
            <input
              type="text"
              name="quantity"
              placeholder="Enter Quantity"
              className="form-control"
              value={update.quantity}
              onChange={handleInputChange}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="price">Price</label>
            <input
              type="text"
              name="price"
              placeholder="Enter Price"
              className="form-control"
              value={update.price}
              onChange={handleInputChange}
            />
          </div>
          <button type="submit" className="btn btn-success">Update</button>
        </form>
      </div>
    </div>
  );
};

export default UpdateProduct;
