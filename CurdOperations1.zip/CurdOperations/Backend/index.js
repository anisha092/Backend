const express = require("express");
const mongoose = require("mongoose");
const product = require("./Models/product.model.js");
const cors = require('cors')
const app = express();

app.use(express.json());
app.use(express.urlencoded({extended: false}))

app.use(cors({origin: 'http://localhost:5173'}))

app.get("/", (req, res) => {
  res.send("hello from node api server updated");
});
app.get("/api/products", async (req, res) => {
  try {
    const products = await product.find({});
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const products = await product.find({ _id: id });
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/products", async (req, res) => {
  try {
    const Product1 = await product.create(req.body);
    res.status(200).json(Product1);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Api
app.put("/api/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const products = await product.findByIdAndUpdate(id, req.body);
    if (!products) {
      return res.status(404).json({ message: "Product not find" });
    }
    const updateProducts = await product.find({ _id: id });
    res.status(200).json(updateProducts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Products;
app.delete("/api/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByIdAndDelete(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.status(200).json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

mongoose
  .connect(
    "mongodb+srv://AvinashChugh:Qwerty14328@cluster0.xmyncdb.mongodb.net/Node-Api?retryWrites=true"
  )
  .then(() => {
    console.log("connected successfully");
    app.listen(3000, () => {
      console.log("Server is running on");
    });
  })
  .catch((err) => {
    console.log(err);
  });
