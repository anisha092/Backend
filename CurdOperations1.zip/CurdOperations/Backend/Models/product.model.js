const { Timestamp } = require('mongodb');
const mongoose = require('mongoose');
const products = mongoose.Schema(
    {
        name: {
            type: String,
            require: [true,"Add the product name please"],
        },
        quantity: {
            type: Number,
            require: [true,"Quantity plase"],
            default: 0
        },
        price: {
            type: Number,
            require: [true,"price plase"],
            default: 0
        }
    },
    {
        Timestamps:true
    }
)
const Product = mongoose.model("products", products)
module.exports = Product;